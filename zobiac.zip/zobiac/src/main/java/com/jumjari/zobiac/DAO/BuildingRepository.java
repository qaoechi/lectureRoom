package com.jumjari.zobiac.DAO;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jumjari.zobiac.entity.Building;

public interface BuildingRepository extends JpaRepository<Building, Integer> {
    Optional<Building> findByEngShort(String engShort);
}