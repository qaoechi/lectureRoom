package com.jumjari.zobiac.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.jumjari.zobiac.entity.Classroom;

public interface ClassroomRepository extends JpaRepository<Classroom, Long> {
    @EntityGraph(attributePaths = "room")
    @Query(value = """
        SELECT c
        FROM Classroom c
        JOIN FETCH c.room r
        WHERE r.building = :building AND c.actived = true
        ORDER BY r.floor ASC, r.number ASC
    """)
    List<Classroom> findAllByBuildingTrue(String building);

    @EntityGraph(attributePaths = "room")
    @Query(value = """
        SELECT c
        FROM Classroom c
        JOIN FETCH c.room r
        WHERE r.building = :building
        ORDER BY r.floor ASC, r.number ASC
    """)
    List<Classroom> findAllByBuilding(String building);
    
    @EntityGraph(attributePaths = "room")
    List<Classroom> findAllByRoom_BuildingAndActivedTrue(String name);
    @EntityGraph(attributePaths = "room")
    Optional<Classroom> findByIdAndActivedTrue(Long id);
    @EntityGraph(attributePaths = "room")
    Optional<Classroom> findById(Long id);
}