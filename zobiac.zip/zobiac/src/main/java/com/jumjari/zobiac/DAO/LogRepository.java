package com.jumjari.zobiac.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jumjari.zobiac.entity.ClassroomLog;

public interface LogRepository extends JpaRepository<ClassroomLog, Long>{
    List<ClassroomLog> findAllByClassroomId(Long classroomId);
}