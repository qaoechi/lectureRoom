package com.jumjari.zobiac.DAO;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jumjari.zobiac.entity.Room;

public interface RoomRepository extends JpaRepository<Room, Long> {
    List<Room> findAllByBuilding(String building);
    Optional<Room> findByBuildingAndNumberAndFloor(String building, String number, Byte floor);
}