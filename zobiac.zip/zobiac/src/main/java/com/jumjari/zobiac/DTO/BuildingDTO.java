package com.jumjari.zobiac.DTO;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class BuildingDTO {
    private Long id;
    private String korFull;
    private String korShort;
    private String engShort;
    private Integer group;
}