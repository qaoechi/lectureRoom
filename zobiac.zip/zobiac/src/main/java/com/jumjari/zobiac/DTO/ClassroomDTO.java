package com.jumjari.zobiac.DTO;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ClassroomDTO {
    private Long id;
    private Boolean actived;
    private RoomDTO room;
    private String name;
    private String direction;
    private Integer type;
    private Byte count;
    private ClassroomDTO parent;
    private String memo;
}