package com.jumjari.zobiac.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PositiveOrZero;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ClassroomForm {
    private Long classroomId;
    @NotBlank(message = "건물 이름은 필수")
    private String building;
    @NotBlank(message = "호수가 없다면 층만 입력")
    private String number;
    private Boolean floor;
    private String name;
    @NotBlank(message = "모르면 0")
    private String direction;
    @NotBlank(message = "모르면 0")
    private Integer type;
    @NotBlank(message = "문 수를 입력하세요")
    @PositiveOrZero(message = "0 이상의 정수만 입력 가능")
    private Byte count;
    private Long parentId;
    private String memo;
}
