package com.jumjari.zobiac.DTO;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class ClassroomTable {
    private Integer id;
    private String room;
    private String sign;
    private String front;
    private String back;
    private String memo;
}