package com.jumjari.zobiac.DTO;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class LogDTO {
    private Integer id;
    private Integer classroomId;
    private String state;
    private String before;
    private String after;
    private LocalDateTime time;
}