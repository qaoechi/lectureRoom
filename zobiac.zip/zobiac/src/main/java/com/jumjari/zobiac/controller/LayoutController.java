package com.jumjari.zobiac.controller;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletResponse;

import lombok.RequiredArgsConstructor;

import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.DTO.ClassroomForm;
import com.jumjari.zobiac.DTO.LogDTO;
import com.jumjari.zobiac.DTO.RoomDTO;
import com.jumjari.zobiac.service.application.GeneralService;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequiredArgsConstructor
@RequestMapping("/jumjari/client")
public class LayoutController {
    private final GeneralService service;

    @GetMapping("")
    public String connectFirst() {
        return "redirect:/jumjari/client/classroom";
    }
    @GetMapping("/classroom")
    public String getMethodName() {
        return "redirect:/jumjari/client/classroom/beomjeong";
    }

    @GetMapping("/classroom/{building}")
    public String classroomPage(
        @PathVariable("building") String building,
        Model model
    ) {
        model.addAllAttributes(Map.of(
            "sidebar_fragment", "classroom",
            "buildings", service.getBuildings(),
            "main", "classroom",
            "building", service.getKorFull(building),
            "classrooms", service.getResult(service.getKorShort(building)),
            "engShort", building
            )
        );
        return "layout";
    }

    @GetMapping("/classroom/{building}/editor")
    public String classroomEditor(
        @PathVariable("building") String building,
        HttpServletResponse response,
        Model model) {
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        model.addAllAttributes(Map.of(
            "sidebar_fragment", "classroom",
            "engShort", building,
            "buildings", service.getBuildings(),
            "main", "editor",
            "building", service.getKorFull(building),
            // "classroomDTO", new ClassroomDTO(),
            "classroomForm", new ClassroomForm(),
            "classroomList", service.getEditorClassrooms(service.getKorShort(building)),
            "roomList", service.getRooms(service.getKorShort(building))
            )
        );
        return "layout";
    }

    @PostMapping("/classroom/{building}/update")
    public String updateRoom(
        @ModelAttribute("classroom") ClassroomForm form,
        @PathVariable("building") String building
    ) {
        int a = Character.getNumericValue(form.getNumber().charAt(0));
        ClassroomDTO dto = new ClassroomDTO(
            form.getClassroomId(),
            true,
            new RoomDTO(
                null,
                form.getBuilding(),
                form.getNumber(),
                form.getFloor() ? (byte)(a * -1) : (byte)a),
            form.getName(), form.getDirection(), form.getType(), form.getCount(),
            service.getClassroom(form.getParentId()), form.getMemo());
        service.save(dto);
        return "redirect:/jumjari/client/classroom/" + building + "/editor";
    }

    @PostMapping("/classroom/{building}/delete")
    public String inactiveRoom(
        @ModelAttribute("classroom") ClassroomForm form,
        @PathVariable("building") String building
    ) {
        service.inactive(form.getClassroomId());
        return "redirect:/jumjari/client/classroom/" + building + "/editor";
    }
    
    @GetMapping("/classroom/{building}/history")
    public String classroomHistory(
        @PathVariable("building") String building,
        Model model) {
        model.addAllAttributes(Map.of(
            "sidebar_fragment", "classroom",
            "buildings", service.getBuildings(),
            "main", "history",
            "engShort", building,
            "building", service.getKorFull(building),
            "classrooms", service.getHistotryClassrooms(service.getKorShort(building))
            )
        );
        return "layout";
    }
    
    @GetMapping("/classroom/{building}/history/{roomId}")
    @ResponseBody
    public List<LogDTO> getMethodName(@PathVariable("roomId") Long id) {
        return service.getRoomLogs(id);
    }
    

    @GetMapping("/classroom/{building}/download")
    public ResponseEntity<byte[]> classroomDownload(@PathVariable("building") String building) {
        HttpHeaders headers =new HttpHeaders();
        headers.setContentType(new MediaType("text", "csv", StandardCharsets.UTF_8));
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + building + ".csv\"");
        return new ResponseEntity<>(service.getCSV(building), headers, HttpStatus.OK);
    }
}