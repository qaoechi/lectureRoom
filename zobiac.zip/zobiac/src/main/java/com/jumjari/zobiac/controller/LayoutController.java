package com.jumjari.zobiac.controller;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.DTO.RoomDTO;
import com.jumjari.zobiac.service.BuildingService;
import com.jumjari.zobiac.service.ClassroomService;
import com.jumjari.zobiac.service.GeneralService;
import com.jumjari.zobiac.service.RoomService;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequestMapping("/jumjari/client")
public class LayoutController {
    private final GeneralService service;
    private final BuildingService buildingS;
    private final ClassroomService classroomS;
    private final RoomService roomS;


    public LayoutController(GeneralService service, BuildingService buildinS, ClassroomService classroomS, RoomService roomS) {
        this.service = service;
        this.buildingS = buildinS;
        this.classroomS = classroomS;
        this.roomS = roomS;
    }
    

    @GetMapping("")
    public String connectFirst() {
        return "redirect:/jumjari/client/classroom";
    }
    @GetMapping("/classroom")
    public String getMethodName() {
        return "redirect:/jumjari/client/classroom/beomjeong";
    }

    @GetMapping("/classroom/{building}")
    public String classroomPage(
        @PathVariable("building") String building,
        Model model
    ) {
        model.addAllAttributes(Map.of(
            "sidebar_fragment", "classroom",
            "buildings", buildingS.getAllBuildings(),
            "main_fragment", "classroom",
            "building", buildingS.getKorFull(building),
            "classrooms", service.getResult(buildingS.getKorShort(building)),
            "engShort", building
            )
        );
        return "layout";
    }

    @GetMapping("/classroom/{building}/editor")
    public String classroomEditor(
        @PathVariable("building") String building,
        HttpServletResponse response,
        Model model) {
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);

        model.addAllAttributes(Map.of(
            "sidebar_fragment", "classroom",
            "engShort", building,
            "buildings", buildingS.getAllBuildings(),
            "main_fragment", "editor",
            "building", buildingS.getKorFull(building),
            "classroomDTO", new ClassroomDTO(),
            "classroomList", classroomS.getClassroomByBuildingName(buildingS.getKorShort(building)),
            "roomList", roomS.getRoomsByBuilding(buildingS.getKorShort(building))
            )
        );
        return "layout";
    }

    @PostMapping("/classroom/{building}/update")
    public String updateRoom(
        @ModelAttribute("classroom") ClassroomDTO classroomDto,
        @RequestParam(name = "floor", defaultValue = "1") Byte floor,
        @RequestParam(name = "parentID", required = false) Long parent,
        @PathVariable("building") String building
    ) {
        RoomDTO roomDto = classroomDto.getRoom();
        roomDto.setFloor((byte)(floor * Character.getNumericValue(roomDto.getNumber().charAt(0))));
        if (parent != null) classroomDto.setParent(classroomS.getClassroomById(parent));
        service.save(classroomDto);
        return "redirect:/jumjari/client/classroom/" + building + "/editor";
    }

    @PostMapping("/classroom/{building}/delete")
    public String inactiveRoom(
        @ModelAttribute("classroom") ClassroomDTO classroomDto,
        @PathVariable("building") String building
    ) {
        service.inactive(classroomDto);
        return "redirect:/jumjari/client/classroom/" + building + "/editor";
    }
    
    @GetMapping("/classroom/{building}/history")
    public String classroomHistory(Model model) {
        model.addAllAttributes(Map.of(
            "sidebar_fragment", "classroom",
            "buildings", buildingS.getAllBuildings(),
            "main_fragment", "classroom"));
        return "layout";
    }

    @GetMapping("/classroom/{building}/download")
    public ResponseEntity<byte[]> classroomDownload(@PathVariable("building") String buildingName) {
        HttpHeaders headers =new HttpHeaders();
        headers.setContentType(new MediaType("text", "csv", StandardCharsets.UTF_8));
        headers.set(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + buildingName + ".csv\"");
        return new ResponseEntity<>(null, headers, HttpStatus.OK);
    }
}