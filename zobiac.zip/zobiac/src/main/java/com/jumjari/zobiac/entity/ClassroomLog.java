package com.jumjari.zobiac.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name = "classroom_log")
public class ClassroomLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JoinColumn(name = "classroom_id")
    private Integer classroomId;
    @Column(name = "state")
    private String state;
    @Column(name = "before_state")
    private String before;
    @Column(name = "after_state")
    private String after;
    @Column(name = "updated_at", updatable = false, insertable = false)
    private LocalDateTime time;
    //FK
    // @Column(name = "updated_user")
    // @JoinColumn(name = "user_id")
    // @ManytoOne
    // @JoinColumn(
    //  name = "user_id",
    //  foreignKey = @ForeignKey(name = ???))
    // private Long userId;
}