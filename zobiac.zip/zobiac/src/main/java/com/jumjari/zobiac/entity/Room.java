package com.jumjari.zobiac.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(
    name = "rooms",
    uniqueConstraints = @UniqueConstraint(
        name = "unique_room",
        columnNames = {"building_name", "room_number"}
    )
)
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "building_name", nullable = false, length = 31)
    private String building;
    @Column(name = "room_number", nullable = false, length = 5)
    private String number;
    @Column(name = "room_floor", nullable = false)
    private Byte floor;
}