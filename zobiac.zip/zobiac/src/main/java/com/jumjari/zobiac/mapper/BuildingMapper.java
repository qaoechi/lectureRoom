package com.jumjari.zobiac.mapper;

import org.mapstruct.Mapper;

import com.jumjari.zobiac.DTO.BuildingDTO;
import com.jumjari.zobiac.entity.Building;

@Mapper(componentModel = "spring")
public interface BuildingMapper {
    BuildingDTO toDTO(Building classroom);
    Building toEntity(BuildingDTO dto);
}