package com.jumjari.zobiac.mapper;

import org.mapstruct.Mapper;

import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.entity.Classroom;

@Mapper(componentModel = "spring", uses = RoomMapper.class)
public interface ClassroomMapper {
    ClassroomDTO toClassroomDTO(Classroom classroom);
    Classroom toClassroomEntity(ClassroomDTO dto);
}