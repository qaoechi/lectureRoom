package com.jumjari.zobiac.mapper;

import org.mapstruct.Mapper;

import com.jumjari.zobiac.DTO.LogDTO;
import com.jumjari.zobiac.entity.ClassroomLog;

@Mapper(componentModel = "spring")
public interface LogMapper {
    LogDTO toDTO(ClassroomLog Log);
    ClassroomLog toEntity(LogDTO dto);
}