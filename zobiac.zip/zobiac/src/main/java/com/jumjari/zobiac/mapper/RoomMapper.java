package com.jumjari.zobiac.mapper;

import org.mapstruct.Mapper;

import com.jumjari.zobiac.DTO.RoomDTO;
import com.jumjari.zobiac.entity.Room;

@Mapper(componentModel = "spring")
public interface RoomMapper {
    RoomDTO toRoomDTO(Room Room);
    Room toRoomEntity(RoomDTO dto);
}