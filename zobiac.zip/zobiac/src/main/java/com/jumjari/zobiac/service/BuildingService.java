package com.jumjari.zobiac.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jumjari.zobiac.DAO.BuildingRepository;
import com.jumjari.zobiac.mapper.BuildingMapper;
import com.jumjari.zobiac.DTO.BuildingDTO;

@Service
public class BuildingService {
    private final BuildingRepository repository;
    private final BuildingMapper mapper;

    public BuildingService(BuildingRepository repository, BuildingMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }    

    public List<BuildingDTO> getAllBuildings() {
        return repository.findAll()
                .stream()
                .map(mapper::toDTO)
                .toList();
    }
    public String getKorFull(String engShort) {
        return repository.findByEngShort(engShort)
                .map(mapper::toDTO)
                .map(BuildingDTO::getKorFull)
                .orElse("error");
    }
    public String getKorShort(String engShort) {
        return repository.findByEngShort(engShort)
                .map(mapper::toDTO)
                .map(BuildingDTO::getKorShort)
                .orElse("error");
    }
}