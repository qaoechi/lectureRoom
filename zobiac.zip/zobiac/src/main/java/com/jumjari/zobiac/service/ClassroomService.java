package com.jumjari.zobiac.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jumjari.zobiac.DAO.ClassroomRepository;
import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.entity.Classroom;
import com.jumjari.zobiac.mapper.ClassroomMapper;

@Service
public class ClassroomService {
    private final ClassroomRepository repository;
    private final ClassroomMapper mapper;

    public ClassroomService(
        ClassroomRepository repository,
        RoomService roomService,
        ClassroomMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<ClassroomDTO> getClassroomByBuildingName(String building) {
        return repository.findAllByBuilding(building)
                .stream()
                .map(mapper::toClassroomDTO)
                .toList();
    }
    public ClassroomDTO getClassroomById(Long id) {
        if (id == null) return null;
        return repository.findById(id)
                .map(mapper::toClassroomDTO)
                .orElse(null);
    }

    public ClassroomDTO saveClassroom(ClassroomDTO dto) {
        dto.setActived(true);
        return mapper.toClassroomDTO(repository.save(mapper.toClassroomEntity(dto)));
    }
    public ClassroomDTO updateClassroom(ClassroomDTO dto) {
        // Classroom classroom = repository.findById(dto.getId())
        //     .orElseThrow(() -> new EntityNotFoundException());
        //     // classroom.setActived(true);
        //     System.out.println("업데이트 내부 classroom: " + classroom);
        return mapper.toClassroomDTO(repository.save(mapper.toClassroomEntity(dto)));
    }

    public void inactiveClassroom(ClassroomDTO dto) {
        // Classroom classroom = repository.findByIdAndActivedTrue(dto.getId())
        //     .orElseThrow(() -> new IllegalArgumentException("classroom 없음"));
        // classroom.setActived(false);            
        // return;
        Classroom classroom = repository.findById(dto.getId())
            .orElse(null);
        classroom.setActived(false);
        repository.save(classroom);
        return;
    }
    public void delete(ClassroomDTO dto) {
        repository.deleteById(dto.getId());
    }
}