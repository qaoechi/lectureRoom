package com.jumjari.zobiac.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.DTO.ClassroomTable;
import com.jumjari.zobiac.DTO.LogDTO;
import com.jumjari.zobiac.DTO.RoomDTO;

@Service
public class GeneralService {
    private final ClassroomService classroomS;
    private final LogJSONService logS;

    public GeneralService(ClassroomService classroomS, LogJSONService logS) {
        this.classroomS = classroomS;
        this.logS = logS;
    }

    public List<ClassroomTable> getresult(String buliding) {
        List<ClassroomTable> result = new ArrayList<>();

        List<ClassroomDTO> classroomList = classroomS.getClassroomByBuildingName(buliding);
        for (ClassroomDTO classroom : classroomList) {
            RoomDTO room = classroom.getRoom();
            String floor = (room.getFloor() < 0) ? "B" + room.getNumber() : room.getNumber();
            String sign;
            if(floor.length() <= 2) {
                sign = classroom.getName();
            } else {
                sign = room.getBuilding() + " " + floor;
                if (!classroom.getName().isEmpty()) {
                    sign += " " + classroom.getName();
                }
            }
            if(classroom.getDirection().equals("left")) {
                sign = "←" + sign;
            } else if (classroom.getDirection().equals("right")) {
                sign = sign + "→";
            }
            String front = null, back = null, memo = null;
            switch (classroom.getCount()) {
                case 1 -> front = sign;
                case 2 -> {
                    front = sign + "앞";
                    back = sign + "뒤";
                }
                case 3 ->{
                    front = sign + "앞";
                    back = sign + "뒤";
                    memo = sign + "중";
                }
            }
            if (memo == null) memo = "";
            memo = memo + "\n" + classroom.getMemo();

            ClassroomTable row = new ClassroomTable(
                classroom.getId(),
                classroom.getRoom(),
                sign,
                front,
                back,
                memo);
            result.add(row);
        }
        return result;
    }

    public String getJSON(List<ClassroomDTO> classrooms) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (ClassroomDTO classroom : classrooms) {
            sb.append("{\"id\":").append(classroom.getId()).append(",");
            sb.append("\"building\":\"").append(classroom.getRoom().getBuilding()).append("\",");
            sb.append("\"number\":\"").append(classroom.getRoom().getNumber()).append("\",");
            sb.append("\"floor\":").append(classroom.getRoom().getFloor()).append(",");
            sb.append("\"name\":\"").append(classroom.getName()).append("\",");
            sb.append("\"direction\":").append(classroom.getDirection()).append(",");
            sb.append("\"type\":").append(classroom.getType()).append(",");
            sb.append("\"count\":").append(classroom.getCount()).append(",");
            sb.append("\"parent\":\"").append(classroom.getParent().getId()).append("\",");
            sb.append("\"memo\":\"").append(classroom.getMemo()).append("\"},");
            // sb.append("\"parent\":\"").append((Objects.toString(room.getParent(), ""))).append("\",");
            // sb.append("\"memo\":\"").append(Objects.toString(room.getMemo(), "")).append("\"},");
        }
        sb.setCharAt(sb.length() - 1, ']');

        return sb.toString();
    }
    
    @Transactional
    public void save(ClassroomDTO classroom) {
        logS.LogJSON(classroom);
    }

    @Transactional
    public void delete(ClassroomDTO classroomDto, RoomDTO roomDto) {
        classroomS.inactiveClassroom(classroomDto);
        LogDTO log = new LogDTO();
        log.setState("delete");
        log.setBefore(null);
        log.setAfter(null);
    }
}