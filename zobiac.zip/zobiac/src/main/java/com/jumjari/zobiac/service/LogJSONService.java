package com.jumjari.zobiac.service;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.DTO.LogDTO;
import com.jumjari.zobiac.DTO.RoomDTO;

@Service
public class LogJSONService {
    private final ClassroomService classroomS;
    private final RoomService roomS;
    private final LogService logS;

    public LogJSONService(ClassroomService classroomS, RoomService roomS, LogService logS) {
        this.classroomS = classroomS;
        this.roomS = roomS;
        this.logS = logS;
    }

    @Transactional
    public void LogJSON(ClassroomDTO classroom) {
        LogDTO log = new LogDTO();
        Map<String, Object> before = new HashMap<>();            
        Map<String, Object> after = new HashMap<>();  
        Set<String> exclusive = Set.of("id", "room");

        RoomDTO roomDto = classroom.getRoom();
        RoomDTO oldRoom = roomS.getRoomByContent(
            roomDto.getBuilding(),
            roomDto.getNumber(),
            roomDto.getFloor()
            );
        if (oldRoom == null) {
            roomDto = roomS.save(roomDto);
            classroom.setRoom(roomDto);
        } else {
            classroom.setRoom(oldRoom);
        }
        Integer flag = classroom.getId();
        ClassroomDTO oldClassroom = classroomS.getClassroomById(classroom.getId());
        System.out.println(oldClassroom);
        if (oldClassroom == null) {
            classroom = classroomS.saveClassroom(classroom);
        } else {
            classroomS.updateClassroom(classroom);
        }
        System.out.println(classroomS.getClassroomById(classroom.getId()));
        /*  ClassroomDTO(id=12, actived=true, room=RoomDTO(id=15, building=범정, number=8888, floor=8), name=타코피, direction=left, type=null, count=1, parent=null, memo=)
            ClassroomDTO(id=12, actived=true, room=RoomDTO(id=15, building=범정, number=8888, floor=8), name=타코피, direction=left, type=null, count=1, parent=null, memo=)
    이거처럼 room이 수정 안 되는거 같음 */


        log.setClassroomId(classroom.getId());
        if (flag == null) {
            log.setState("create");
            log.setBefore(null);
            log.setAfter(null);
            logS.save(log);
            return;
        }
        log.setState("update");

        for (Field field : ClassroomDTO.class.getDeclaredFields()) {
            if (exclusive.contains(field.getName())) continue;
            field.setAccessible(true);

            Object oldValue;
            Object preValue;
            try {
                if (oldClassroom == null) continue;

                oldValue = field.get(oldClassroom);
                preValue = field.get(classroom);

                if (oldValue.equals(preValue)) continue;

                before.put(field.getName(), oldValue);
                after.put(field.getName(), preValue);
            } catch (Exception e) {
                System.err.println("필드 접근 불가" + field.getName());
                continue;
            }
        }

        for (Field field : RoomDTO.class.getDeclaredFields()) {
            if (exclusive.contains(field.getName())) continue;
            field.setAccessible(true);  
            
            Object oldValue;
            Object preValue;
            try {
                if (oldRoom == null) continue;

                oldValue = field.get(oldRoom);
                preValue = field.get(roomDto);

                if (oldValue.equals(preValue)) continue;

                before.put(field.getName(), oldValue);
                after.put(field.getName(), preValue);
            } catch (Exception e) {
                System.err.println("필드 접근 불가" + field.getName());
                continue;
            }
        }

        ObjectMapper objectMapper = new ObjectMapper();
        try {
            log.setBefore(objectMapper.writeValueAsString(before));
            log.setAfter(objectMapper.writeValueAsString(after));
            if (log.getAfter() == null) {
                log.setBefore(null);
                log.setAfter(null);
                return;
            }
        } catch (Exception e) {
            System.err.println("JSON 변환 실패: " + e.getMessage());
        }

        logS.save(log);
    }
}