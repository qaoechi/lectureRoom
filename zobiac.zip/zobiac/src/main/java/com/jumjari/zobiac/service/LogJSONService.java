package com.jumjari.zobiac.service;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.DTO.LogDTO;
import com.jumjari.zobiac.DTO.RoomDTO;

@Service
public class LogJSONService {
    private final ClassroomService classroomS;
    private final RoomService roomS;
    private final LogService logS;

    public LogJSONService(ClassroomService classroomS, RoomService roomS, LogService logS) {
        this.classroomS = classroomS;
        this.roomS = roomS;
        this.logS = logS;
    }

    @Transactional
    public void LogJSON(ClassroomDTO classroom) {
        //수정에서 actived가 null이 되는 문제가 있는지 확인해봐
        //oldRoom 이랑 jjinOld랑 역할 겹치는데 합칠 수 있는지 보자
        LogDTO log = new LogDTO();
        Map<String, Object> before = new HashMap<>();
        Map<String, Object> after = new HashMap<>();  

        RoomDTO formRoom = classroom.getRoom();
        RoomDTO oldRoom = roomS.getRoomByContent(
            formRoom.getBuilding(),
            formRoom.getNumber(),
            formRoom.getFloor()
            );

        if (oldRoom == null) {
            formRoom = roomS.save(formRoom);
            
            classroom.setRoom(formRoom);
        } else {
            classroom.setRoom(oldRoom);
            formRoom.setRoomId(oldRoom.getRoomId());
        }

        Long flag = classroom.getId();
        ClassroomDTO oldClassroom = classroomS.getClassroomById(classroom.getId());
        if (oldClassroom == null) {
            classroom = classroomS.saveClassroom(classroom);
        } else {
            classroomS.updateClassroom(classroom);
            oldRoom = oldClassroom.getRoom();
        }

        log.setClassroomId(classroom.getId());
        if (flag == null) {
            //id들 다 나오게 했는데 있던걸 있던 방으로 했는데 왜 최근게 create로 뜬거지? 그니까 처음부터 봐바
            log.setState("create");
            log.setBefore(null);
            log.setAfter(snapshot(classroom));
            logS.save(log);
            return;
        }
        log.setState("update");

        for (Field field : ClassroomDTO.class.getDeclaredFields()) {
            if ("room".equals(field.getName())) continue;
            field.setAccessible(true);

            Object oldValue;
            Object preValue;
            try {
                if (oldClassroom == null) continue;

                oldValue = field.get(oldClassroom);
                preValue = field.get(classroom);

                if (oldValue.equals(preValue)) continue;

                before.put(field.getName(), oldValue);
                after.put(field.getName(), preValue);
            } catch (Exception e) {
                System.err.println("classroom 필드 접근 불가" + field.getName());
                continue;
            }
        }

        for (Field field : RoomDTO.class.getDeclaredFields()) {
            field.setAccessible(true);  
            
            Object oldValue;
            Object preValue;
            try {
                if (oldRoom == null) continue;

                oldValue = field.get(oldRoom);
                preValue = field.get(formRoom);

                if (oldValue.equals(preValue)) continue;
                before.put(field.getName(), oldValue);
                after.put(field.getName(), preValue);
            } catch (Exception e) {
                System.err.println("room 필드 접근 불가" + field.getName());
                continue;
            }
        }

        ObjectMapper objectMapper = new ObjectMapper();
        try {
            log.setBefore(objectMapper.writeValueAsString(before));
            log.setAfter(objectMapper.writeValueAsString(after));
        } catch (Exception e) {
            System.err.println("JSON 변환 실패: " + e.getMessage());
        }

        logS.save(log);
    }

    public void inactive(ClassroomDTO classroomDto) {
        // 진짜 classroom이 없어지는걸 delete라 할거라 이거도 update
        ClassroomDTO classroom = classroomS.getClassroomById(classroomDto.getId());

        LogDTO log = new LogDTO();
        log.setClassroomId(classroom.getId());
        log.setState("update");
        log.setBefore("{\"actived\": true}");
        log.setAfter("{\"actived\": false}");
        logS.save(log);
    }

    private String snapshot(ClassroomDTO dto) {
        String classroomSnapshot = null;
        Map<String, Object> snapshot = new HashMap<>();
        ObjectMapper objectMapper = new ObjectMapper();

        for (Field field : ClassroomDTO.class.getDeclaredFields()) {
            // if (field.toString().equals("room")) continue;
            if ("room".equals(field.getName())) continue;
            field.setAccessible(true);
            Object value;
            try {
                value = field.get(dto);
                snapshot.put(field.getName(), value);
            } catch (Exception e) {
                System.err.println("스냅샷 classroom 필드 접근 불가" + field.getName());
                continue;
            }
        }
        for (Field field : RoomDTO.class.getDeclaredFields()) {
            field.setAccessible(true);
            Object value;
            try {
                value = field.get(dto.getRoom());
                snapshot.put(field.getName(), value);
            } catch (Exception e) {
                System.err.println("스냅샷 room 필드 접근 불가" + field.getName());
                continue;
            }
        }

        try {
            classroomSnapshot = objectMapper.writeValueAsString(snapshot);
        } catch (Exception e) {
            System.err.println("JSON 변환 실패: " + e.getMessage());
        }


        return classroomSnapshot;
    }
}