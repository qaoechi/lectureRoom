package com.jumjari.zobiac.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.jumjari.zobiac.DAO.LogRepository;
import com.jumjari.zobiac.DTO.LogDTO;
import com.jumjari.zobiac.mapper.LogMapper;

@Service
public class LogService {
    private final LogRepository repository;
    private final LogMapper mapper;

    public LogService(LogRepository repository, LogMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<LogDTO> getLogByClassroom(Integer classroom) {
        return repository.findAllByClassroomId(classroom)
                .stream()
                .map(mapper::toDTO)
                .toList();
    }

    public void save(LogDTO dto) {
        repository.save(mapper.toEntity(dto));
        return;
    }
}