package com.jumjari.zobiac.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.jumjari.zobiac.DAO.RoomRepository;
import com.jumjari.zobiac.DTO.RoomDTO;
import com.jumjari.zobiac.mapper.RoomMapper;

@Service
public class RoomService {
    private final RoomRepository repository;
    private final RoomMapper mapper;

    public RoomService(RoomRepository repository, RoomMapper mapper) {
        this.repository = repository;
        this.mapper = mapper;
    }

    public List<RoomDTO> getRooms() {
        return repository.findAll()
                .stream()
                .map(mapper::toRoomDTO)
                .collect(Collectors.toList());
    }
    public List<RoomDTO> getRoomsByBuilding(String building) {
        return repository.findAllByBuilding(building)
                .stream()
                .map(mapper::toRoomDTO)
                .collect(Collectors.toList());
    }
    public RoomDTO getRoomById(Long id) {
        return repository.findById(id)
                .map(mapper::toRoomDTO)
                .orElse(null);
    }
    public RoomDTO getRoomByContent(String building, String number, Byte floor) {
        return repository.findByBuildingAndNumberAndFloor(building, number, floor)
                .map(mapper::toRoomDTO)
                .orElse(null);
    }

    public RoomDTO save(RoomDTO dto) {
        return mapper.toRoomDTO(repository.save(mapper.toRoomEntity(dto)));
    }

    public void delete(RoomDTO dto) {
        repository.deleteById(dto.getRoomId());
    }
}