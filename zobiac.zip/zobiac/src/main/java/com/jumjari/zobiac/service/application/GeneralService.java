package com.jumjari.zobiac.service.application;

import java.util.List;

import org.springframework.stereotype.Service;
import com.jumjari.zobiac.service.domain.RoomReader;
import jakarta.transaction.Transactional;

import lombok.RequiredArgsConstructor;

import com.jumjari.zobiac.service.domain.BuildingReader;
import com.jumjari.zobiac.service.domain.ClassroomReader;
import com.jumjari.zobiac.service.domain.LogReader;
import com.jumjari.zobiac.DTO.BuildingDTO;
import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.DTO.RoomDTO;
import com.jumjari.zobiac.DTO.ClassroomTable;
import com.jumjari.zobiac.DTO.LogDTO;

@Service
@RequiredArgsConstructor
public class GeneralService {
    //이거 그 이름으로 쿼리만드는거 레포지토리에 지정하지 않아도 자동으로 생성될 수 있는거들이라 주석처리해도 오류 안 나는거 같음. 다시 하기
    //repository-reader-service계층 메서드들 처음부터 확인
    private final BuildingReader bReader;
    private final ClassroomReader cReader;
    private final RoomReader rReader;
    private final LogReader lReader;
    private final Manager manager;

    public List<BuildingDTO> getBuildings() {
        return bReader.getAllBuildings();
    }
    public String getKorFull(String engShort) {
        return bReader.getBuilding(engShort).getKorFull();
    }
    public String getKorShort(String engShort) {
        return bReader.getBuilding(engShort).getKorShort();
    }

    public List<ClassroomDTO> getEditorClassrooms(String building) {
        return cReader.getClassroomsByBuilding(building);
    }
    public ClassroomDTO getClassroom(Long id) {
        return cReader.getClassroomById(id);
    }
    public List<ClassroomDTO> getHistotryClassrooms(String building) {
        return cReader.getHistoryClassrooms(building);
    }

    public List<RoomDTO> getRooms(String building) {
        return rReader.getRoomsByBuilding(building);
    }

    public List<LogDTO> getRoomLogs(Long id) {
        return lReader.getLogByClassroom(id);
    }

    public List<ClassroomTable> getResult(String buliding) {
        return manager.getResult(buliding);
    }
    
    @Transactional
    public void save(ClassroomDTO classroom) {
        manager.LogJSON(classroom);
    }

    @Transactional
    public void inactive(Long id) {
        cReader.inactiveClassroom(cReader.getClassroomById(id));
        manager.inactive(id);
    }

    public byte[] getCSV(String building) {
        return manager.csv(manager.getResult(getKorShort(building)));
    }
}