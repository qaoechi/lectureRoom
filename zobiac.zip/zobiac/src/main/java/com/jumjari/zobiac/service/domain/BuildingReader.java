package com.jumjari.zobiac.service.domain;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

import com.jumjari.zobiac.DAO.BuildingRepository;
import com.jumjari.zobiac.mapper.BuildingMapper;
import com.jumjari.zobiac.DTO.BuildingDTO;

@Component
@RequiredArgsConstructor
public class BuildingReader {
    private final BuildingRepository repository;
    private final BuildingMapper mapper; 

    public List<BuildingDTO> getAllBuildings() {
        return repository.findAll()
            .stream()
            .map(mapper::toDTO)
            .toList();
    }
    public BuildingDTO getBuilding(String engShort) {
        return repository.findByEngShort(engShort)
            .map(mapper::toDTO)
            .orElse(new BuildingDTO());
    }
}