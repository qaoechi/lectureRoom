package com.jumjari.zobiac.service.domain;

import java.util.List;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

import com.jumjari.zobiac.DAO.ClassroomRepository;
import com.jumjari.zobiac.mapper.ClassroomMapper;
import com.jumjari.zobiac.DTO.ClassroomDTO;
import com.jumjari.zobiac.entity.Classroom;

@Service
@RequiredArgsConstructor
public class ClassroomReader {
    private final ClassroomRepository repository;
    private final ClassroomMapper mapper;

    public List<ClassroomDTO> getClassroomsByBuilding(String building) {
        return repository.findAllByBuildingTrue(building)
            .stream()
            .map(mapper::toClassroomDTO)
            .toList();
    }
    public ClassroomDTO getClassroomById(Long id) {
        if (id == null) return null;
        return repository.findById(id)
            .map(mapper::toClassroomDTO)
            .orElse(null);
    }
    public List<ClassroomDTO> getHistoryClassrooms(String building) {
        return repository.findAllByBuilding(building)
        .stream()
        .map(mapper::toClassroomDTO)
        .toList();
    }

    public ClassroomDTO saveClassroom(ClassroomDTO dto) {
        dto.setActived(true);
        return mapper.toClassroomDTO(repository.save(mapper.toClassroomEntity(dto)));
    }
    public ClassroomDTO updateClassroom(ClassroomDTO dto) {
        return mapper.toClassroomDTO(repository.save(mapper.toClassroomEntity(dto)));
    }

    public void inactiveClassroom(ClassroomDTO dto) {
        Classroom classroom = repository.findById(dto.getId())
            .orElse(null);
        classroom.setActived(false);
        repository.save(classroom);
        return;
    }
    public void delete(ClassroomDTO dto) {
        repository.deleteById(dto.getId());
    }
}