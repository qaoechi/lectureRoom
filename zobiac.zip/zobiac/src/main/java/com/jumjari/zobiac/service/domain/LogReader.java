package com.jumjari.zobiac.service.domain;

import java.util.List;

import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

import com.jumjari.zobiac.DAO.LogRepository;
import com.jumjari.zobiac.mapper.LogMapper;
import com.jumjari.zobiac.DTO.LogDTO;

@Component
@RequiredArgsConstructor
public class LogReader {
    private final LogRepository repository;
    private final LogMapper mapper;

    public List<LogDTO> getAllLogs() {
        return repository.findAll()
            .stream()
            .map(mapper::toDTO)
            .toList();
    }
    public List<LogDTO> getLogByClassroom(Long id) {
        return repository.findAllByClassroomIdOrderByTime(id)
            .stream()
            .map(mapper::toDTO)
            .toList();
    }

    public void save(LogDTO dto) {
        repository.save(mapper.toEntity(dto));
        return;
    }
}