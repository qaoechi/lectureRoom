package com.jumjari.zobiac.service.domain;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

import com.jumjari.zobiac.DAO.RoomRepository;
import com.jumjari.zobiac.mapper.RoomMapper;
import com.jumjari.zobiac.DTO.RoomDTO;

@Service
@RequiredArgsConstructor
public class RoomReader {
    private final RoomRepository repository;
    private final RoomMapper mapper;

    // public List<RoomDTO> getRooms() {
    //     return repository.findAll()
    //         .stream()
    //         .map(mapper::toRoomDTO)
    //         .collect(Collectors.toList());
    // }
    public List<RoomDTO> getRoomsByBuilding(String building) {
        return repository.findAllByBuilding(building)
            .stream()
            .map(mapper::toRoomDTO)
            .collect(Collectors.toList());
    }
    public RoomDTO getRoomByContent(String building, String number, Byte floor) {
        return repository.findByBuildingAndNumberAndFloor(building, number, floor)
            .map(mapper::toRoomDTO)
            .orElse(null);
    }

    public RoomDTO save(RoomDTO dto) {
        return mapper.toRoomDTO(repository.save(mapper.toRoomEntity(dto)));
    }

    public void delete(RoomDTO dto) {
        repository.deleteById(dto.getRoomId());
    }
}