async function loadLogs(link) {
    try {
        const response = await fetch(link);
        if (!response.ok) throw new Error("서버 오류");
        return await response.json();
    } catch (e) {
        console.error(e);
    }
}

document.querySelectorAll(".history-item").forEach(div => {
    div.addEventListener("click", async function() {
        const link = '/jumjari/client/classroom/' + engShort + '/history/' + this.dataset.id;
        const list = await loadLogs(link);
        console.log("list의 타입: " + typeof(list));
        const roomList = document.getElementById("history");

        while (roomList.firstChild) {
            roomList.firstChild.remove();
        }

        list.forEach(item => {
            console.log("item의 타입: " + typeof(item));    
            const div = document.createElement("div");
            div.classList.add("history-item");

            div.textContent = compare(JSON.parse(item.before), JSON.parse(item.after));
            // div.dataset.id = classroom.room.id;

            roomList.appendChild(div);
            //그 이런 느낌임
        })
    })
})
document.getElementById("imsi").addEventListener("click", function() {
    console.log(logs);
})

function compare(before, after) {
    console.log(typeof(before));
    console.log(typeof(after));
    if (before == null) return "create";
    // if (after == null) return "delete";
    return before.id;
}