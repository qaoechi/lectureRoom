document.querySelectorAll(".room-item").forEach(div => {
    div.addEventListener("dragstart", event => {
        event.dataTransfer.setData("text/plain", event.target.dataset.id);
    })
})

document.getElementById("dropZone").addEventListener("dragover", event => {
    event.preventDefault(); //div를 둘때 dragover라는 이벤트를 발행해서 이걸 해야함
    
})

document.getElementById("dropZone").addEventListener("drop", function(event) {
    event.preventDefault();
    const id = event.dataTransfer.getData("text/plain");
    const classroom = classrooms.find(x => x.id == id);
    this.textContent = classroom.room.number + "" + classroom.name;
    document.getElementById("parentId").value = id;
})

document.getElementById("dropZone").addEventListener("click", function() {
    if (this.textContent != null) {
        this.textContent = "부모 강의실";
        document.getElementById("parentId").value = "";
    }
})
function fillParentForm(id) {
    const parent = classrooms.find(x => x.id == id);
    document.getElementById("dropZone").textContent = parent.room.number + "" + parent.name;
    document.getElementById("parentId").value = String(parent.id);
}
function removeParentForm() {
    document.getElementById("dropZone").textContent = "부모 강의실";
}