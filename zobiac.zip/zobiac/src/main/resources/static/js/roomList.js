let selectedRoom = null;

document.querySelectorAll(".room-item").forEach(div => {
    div.addEventListener("click", function() {
        let classroomId;
        let roomId;
        let classroom;
        let room;

        if (this === selectedRoom) {
            selectedRoom.classList.remove("selected");
            selectedRoom = null;
            reset();
        } else {
            if(selectedRoom) {
                selectedRoom.classList.remove("selected");
            }
            this.classList.add("selected");
            selectedRoom = this;

            classroomId = Number(this.dataset.id);
            classroom = classrooms.find(x => x.id == classroomId);
            roomId = Number(classroom.room.roomId);
            room = rooms.find(x => x.roomId == roomId)
        }
        
        reset();
        if (classroom) {
            document.getElementById("building").value = room.building;
            document.getElementById("classroomId").value = classroomId;
            document.getElementById("number").value = room.number;
            (room.floor < 0) ? floorCheck(true): floorCheck(false);
            document.getElementById("name").value = classroom.name;
            document.getElementById("direction").value = classroom.direction;
            document.getElementById("type").value = classroom.type;
            document.getElementById("count").value = classroom.count;
            classroom.parent ? fillParentForm(classroom.parent.id) : null;
            document.getElementById("memo").value = classroom.memo;
        }
    })
})

document.getElementById("building").addEventListener("", function() {
    //이 select의 값이 선택되면 parent의 select가 값이 변경되도록
    //근데 이러면 드래그로 선택하는 방법은 없어지잖아. 그냥 수정으로 건물이 바뀌면 자식 설정은 수정 후 또 수정으로 하는게 맞나?
})

function floorCheck(bool) {
    document.getElementById("floor").checked = bool;
}
function reset() {
    document.getElementById("editorForm").reset();
    removeParentForm();
}