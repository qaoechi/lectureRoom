document.getElementById("editorForm").addEventListener("submit", event => {
    const building = document.getElementById("building");
    const number = document.getElementById("number");
    const classroomId = document.getElementById("classroomId");
    const direction = document.getElementById("direction");
    const type = document.getElementById("type");
    const count = document.getElementById("count");
    const parent = document.getElementById("parentId");

    try {
        preventSubmit(number, number.value === "", "호수를 입력하세요", event);
        preventSubmit(number, number.value.length > 6, "정확한 호수가 너무 깁니다.", event);
        preventSubmit(number, !(/^-?\d+$/.test(number.value)), "숫자와 -(하이픈) 만 입력하세요", event);
        //이 함수도 안 되고 number는 검증할게 많음
        preventSubmit(count, !Number.isFinite(Number(count.value)), "숫자가 아닙니다", event);
        preventSubmit(type, type.value === "", "문 종류를 선택하세요", event);
        preventSubmit(direction, direction.value === "", "방향을 선택하세요", event);
        preventSubmit(building, building.value === "", "건물을 선택하세요", event);    
        preventSubmit(parent, parent.value ? parent.value === classroomId.value : false, "자신을 참조하지 마세요", event);
    } catch (e) {
        console.log(e.message);
    }

})

function preventSubmit(form, bool, message, event) {
    if (bool) {
        alert(message);
        form.focus();
        event.preventDefault();
        throw new Error(message);
    }
}