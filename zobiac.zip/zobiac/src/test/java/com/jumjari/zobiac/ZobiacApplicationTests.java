package com.jumjari.zobiac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZobiacApplicationTests {

	@Test
	void contextLoads() {
	}

}
